

#include "Gremlin.h"


Gremlin::Gremlin() : Battle("Gremlin",DEFAULT_LOOT,DEFAULT_FORCE,DEFAULT_HP_TO_DECREASE) {}

